package com.example.opensourcemovie;

import android.app.Application;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {MovieModelClass.class}, version = 1)
public abstract class  nDatabase extends RoomDatabase {

    public static nDatabase dbInstance;
    public static DAO dao;
    public DAO getDao(){
        return dao;
    }
    public static synchronized nDatabase getDatabaseInstance(Application application){
        if(dbInstance == null) {
            dbInstance = Room.databaseBuilder(application.getApplicationContext(), nDatabase.class, "Database").fallbackToDestructiveMigration().build();
        }
        return dbInstance;
    }
}
