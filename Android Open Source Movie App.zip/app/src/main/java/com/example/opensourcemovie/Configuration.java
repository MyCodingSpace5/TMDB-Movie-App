package com.example.opensourcemovie;

import com.google.gson.Gson;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Configuration{
    private static Retrofit retrofit;
    private static String base_url;

    public static API_TMDB getMovieApiService(){
        if(retrofit == null){
            retrofit = new Retrofit.Builder().baseUrl(base_url).addConverterFactory(GsonConverterFactory.create()).build();
        }
        return retrofit.create(API_TMDB.class);
    }


}
