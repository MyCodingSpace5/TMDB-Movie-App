package com.example.opensourcemovie;

import android.app.Application;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.MutableLiveData;
import androidx.recyclerview.widget.RecyclerView;

import com.example.opensourcemovie.databinding.ActivityMovieBinding;

import java.util.ArrayList;

public class TMDB_API extends RecyclerView.Adapter<TMDB_API.ViewHolder> {
    public MutableLiveData<ArrayList<MovieModelClass>> modelClasses;
    class ViewHolder extends RecyclerView.ViewHolder{
        public ActivityMovieBinding binding;
        public ViewHolder(ActivityMovieBinding newbinding){
            super(newbinding.getRoot());
            this.binding = newbinding;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ActivityMovieBinding binding = DataBindingUtil.inflate(LayoutInflater.from(parent.getContext()), R.layout.activity_movie, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MovieModelClass newMovie = modelClasses.getValue().get(position);
        holder.binding.setMovie(newMovie);
    }

    @Override
    public int getItemCount() {
        return modelClasses.getValue().size();
    }
    public void checkData(){
        MutableLiveData<ArrayList<MovieModelClass>> result = Repository.isDatasetUptodate(modelClasses);
        if(result == null){
            checkData();
        }
        else{
            modelClasses = result;
        }
    }

}
