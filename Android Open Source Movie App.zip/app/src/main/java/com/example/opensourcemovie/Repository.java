package com.example.opensourcemovie;

import static android.os.Looper.getMainLooper;

import android.app.Application;
import android.os.Handler;

import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Repository {
    public ExecutorService newRepo;
    public Handler handler;

    public MutableLiveData<ArrayList<Result>> livedata = new MutableLiveData<>();

    public static DAO dao;
    public Repository(Application application){
        ExecutorService newRepo = Executors.newSingleThreadExecutor();
        nDatabase ndb = nDatabase.getDatabaseInstance(application);
        dao = ndb.getDao();
        handler = new Handler(getMainLooper());
    }
    public void insert(MovieModelClass mvie){
        newRepo.execute(new Runnable() {
            @Override
            public void run() {
                dao.Insert(mvie);
            }
        });
    }
    public void delete(MovieModelClass mvie){
        newRepo.execute(new Runnable() {
            @Override
            public void run() {
                dao.Delete(mvie);
            }
        });

    }
    public ArrayList<MovieModelClass> getByTitle(String title){
        return dao.getAllByTitle(title);
    }
    public MutableLiveData<ArrayList<MovieModelClass>> getById(String id){
        return dao.getAllViaIds(id);
    }
    public static MutableLiveData<ArrayList<MovieModelClass>> isDatasetUptodate(MutableLiveData<ArrayList<MovieModelClass>> dataset){
        if(dao.getMembers() != dataset){
            return dao.getMembers();
        }
        else{
            return null;
        }
    }
    public MutableLiveData<ArrayList<MovieModelClass>> getMutableLiveData(){
        return dao.getMembers();
    }
    public MutableLiveData<ArrayList<MovieModelClass>> update(String api_key){
        MutableLiveData<ArrayList<MovieModelClass>> liveData = new MutableLiveData<>();
        API_TMDB api = Configuration.getMovieApiService();
        Call<Result> call = api.getpopular(api_key);
        call.enqueue(new Callback<Result>() {
            @Override
            public void onResponse(Call<Result> call, Response<Result> response) {
                Result result = response.body();
                liveData.setValue(result.getArray());
                dao.updateMembers(liveData);
            }

            @Override
            public void onFailure(Call<Result> call, Throwable t) {

            }
        });
        return dao.getMembers();
    }



}
