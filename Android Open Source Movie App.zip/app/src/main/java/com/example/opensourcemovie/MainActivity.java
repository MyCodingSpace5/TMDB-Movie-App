



package com.example.opensourcemovie;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;

import com.example.opensourcemovie.databinding.ActivityMainBinding;
import com.example.opensourcemovie.databinding.ActivityMovieBinding;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Viewmodel viewmodel = new Viewmodel(getApplication());
        ActivityMainBinding mainbinding = DataBindingUtil.setContentView(this, R.layout.activity_main);
        TMDB_API api = new TMDB_API();
        api.checkData();
        mainbinding.recycle.setAdapter(api);
    }
}