package com.example.opensourcemovie;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Result {


    @SerializedName("page")
    @Expose
    private Integer pageposition;


    @SerializedName("total_pages")
    @Expose
    private Integer totalpages;

    @SerializedName("total_results")
    @Expose
    private Integer totalResults;

    @SerializedName("results")
    @Expose
    private ArrayList<MovieModelClass> array;

    public Result(int pageposition, int totalpages, int totalresults, ArrayList<MovieModelClass> array){
        this.pageposition = pageposition;
        this.totalpages = totalpages;
        this.totalResults = totalresults;
        this.array = array;
    }

    public Integer getPageposition() {
        return pageposition;
    }

    public void setPageposition(Integer pageposition) {
        this.pageposition = pageposition;
    }

    public Integer getTotalpages() {
        return totalpages;
    }

    public void setTotalpages(Integer totalpages) {
        this.totalpages = totalpages;
    }

    public Integer getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(Integer totalResults) {
        this.totalResults = totalResults;
    }

    public ArrayList<MovieModelClass> getArray() {
        return array;
    }

    public void setArray(ArrayList<MovieModelClass> array) {
        this.array = array;
    }
}
