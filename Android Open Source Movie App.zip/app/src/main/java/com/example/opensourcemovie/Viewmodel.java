package com.example.opensourcemovie;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;

public class Viewmodel extends AndroidViewModel {
    private Repository repository;

    public Viewmodel(@NonNull Application application) {
        super(application);
        this.repository = new Repository(application);
    }
    public MutableLiveData<ArrayList<MovieModelClass>> getMovies(){
        return repository.getMutableLiveData();
    }
}
