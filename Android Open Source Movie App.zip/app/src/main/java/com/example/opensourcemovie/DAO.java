package com.example.opensourcemovie;


import androidx.lifecycle.MutableLiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.ArrayList;

@Dao

public interface DAO {


    @Insert
    void Insert(MovieModelClass movie);



    @Delete
    void Delete(MovieModelClass movieclass);

    @Query("SELECT * FROM MovieModelClass WHERE title == title")
    ArrayList<MovieModelClass> getAllByTitle(String title);

    @Query("SELECT * FROM MOVIEMODELCLASS WHERE id = id")
    MutableLiveData<ArrayList<MovieModelClass>> getAllViaIds(String id);
    @Query("SELECT * FROM MOVIEMODELCLASS")
    MutableLiveData<ArrayList<MovieModelClass>> getMembers();
    @Update
    void updateMembers(MutableLiveData<ArrayList<MovieModelClass>> movieList);
}
