package com.example.opensourcemovie;

import android.app.Application;
import android.content.Intent;

import java.lang.annotation.Target;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.http.*;

public interface API_TMDB {

    @GET("movie/popular")
    Call<Result> getpopular(@Query("api_key") String api_key);
}